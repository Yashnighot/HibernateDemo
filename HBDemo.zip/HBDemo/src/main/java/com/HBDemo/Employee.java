package com.HBDemo;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.Id;

@Entity
@Table(name="emp")
public class Employee {
	@Id
	@Column(name="id")
	int id;
	@Column(name="fname")
	String firstname;
	@Column(name="lname")
	String lastname;
	@Column(name="salary")
	int salary;
	public Employee(int id, String firstname, String lastname, int salary) {
		super();
		this.id = id;
		this.firstname = firstname;
		this.lastname = lastname;
		this.salary = salary;
	}

}
